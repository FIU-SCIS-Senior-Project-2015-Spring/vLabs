<?php
define("_MODULE_VLABSADMIN_MODULEVLABSADMIN", "vLabsAdmin");

?>
