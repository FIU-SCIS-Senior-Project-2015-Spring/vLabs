<?php 

require_once ('../../db/db.php');

if (isset($_POST['action'])) {
    $action = $_POST['action'];
} else {
    $action = "";
}


if ($action == "proceedToCheckout") {
	print_r("checkout");

}elseif ($action == "placeOrder"){
	print_r("place order");
}




?>