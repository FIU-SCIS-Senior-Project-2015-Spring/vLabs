aut
<?php phpinfo(); ?>