<?php
define("_MODULE_EMPTY_MODULEEMPTY", "Empty module");

?>
