<?php
define("_MODULE_SHOPPINGCART", "shoppingcart");

?>
