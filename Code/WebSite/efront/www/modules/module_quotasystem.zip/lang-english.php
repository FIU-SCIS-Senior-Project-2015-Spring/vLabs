<?php
define("_MODULE_QS_MODULEQS", "Quota System");

?>

