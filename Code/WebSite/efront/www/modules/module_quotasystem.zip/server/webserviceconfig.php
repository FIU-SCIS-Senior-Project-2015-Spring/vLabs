<?php

define('WSDL_VL', 'http://ita-provisioner.cis.fiu.edu:8080/axis2/services/VirtualLabs?wsdl');
define('LOCATION_VL','http://ita-provisioner.cis.fiu.edu:8080/axis2/services/VirtualLabs');

define('WSDL_QS', 'http://ita-provisioner.cis.fiu.edu:8080/axis2/services/QuotaSystem?wsdl');
define('LOCATION_QS','http://ita-provisioner.cis.fiu.edu:8080/axis2/services/QuotaSystem');

//define('WSDL_QS', 'http://localhost:8080/axis2/services/QuotaSystem?wsdl');
//define('LOCATION_QS','http://localhost:8080/axis2/services/QuotaSystem');

?>
