<?php
define("_MODULE_QUOTASTORE", "Quota Store");

?>
