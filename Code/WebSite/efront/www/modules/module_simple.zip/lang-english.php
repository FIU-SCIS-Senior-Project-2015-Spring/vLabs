<?php
define("_MODULE_SIMPLE_MODULESIMPLE", "Simple module");

?>
