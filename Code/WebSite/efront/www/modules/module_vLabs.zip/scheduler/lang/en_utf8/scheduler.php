<?php

$string['scheduler'] = 'scheduler';

$string['modulename'] = 'scheduler';
$string['modulenameplural'] = 'schedulerS';

$string['schedulerfieldset'] = 'Custom example fieldset';
$string['schedulerintro'] = 'scheduler Intro';
$string['schedulername'] = 'scheduler Name';

$string['welcomemessage'] = 'Welcome to this newmodule';

?>
