<?php
define("_MODULE_VLABS_MODULEVLABS", "vLabs");

?>
